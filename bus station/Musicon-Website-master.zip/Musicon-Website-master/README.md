# Musicon-Website
This a simple static website using the "Handlebars.js" the templating Engine. This website is created using "Handlebars" which a very   powerful templating engine. It is widely used these days for creating templates.

How to use: 
          You can use this static website as a Tempate to create other websites.
          So, to change the data in the "HomePage" and "Store" you only have to change the data in the "main.js" file.
          You can change the Hompage's heading and the text below the main heading by changing the "title" and "body" in "main.js";
          In the "Store" page. You can add new items by adding the reqiured data in the "context" object(instruments array).
          Once, you change data in the "main.js" the changings will be made automaticalliy, without chanhging the HTML or the CSS.
          The handlebars templates are very useful for creating the re-usable websites.

